package MuhammadRaihanWijayaJmartMR;

public interface Transaction
{   
    
}
